let word=prompt("Welcome to Hangman, Player1! Please enter a word for Player 2 to guess. Be carefull not to let them see!").toUpperCase();
console.log(word);
alert("Welcome to Hangman, Player 2! Now its your turn to guess the correct letters to win the game.")
let revealedLetters=new Array(word.length);
console.log(revealedLetters);
//revealedLetters.fill("-",0);
//console.log(revealedLetters);
revealedLetters.fill(false);
const maxStrikes =6; 
let strikes = 0;
let strikeLetters = new Array(maxStrikes);
drawWordProgress();

function drawStrikeLetters() {
	document.getElementById("strikes").innerHTML = strikeLetters.toString();
}

function drawWordProgress() {
    let dashes=""
    for(let letterIndex=0; letterIndex<word.length; letterIndex++){
        if(revealedLetters[letterIndex]){
            dashes+=word[letterIndex]+" ";
        }
        else{
            dashes+="-";
        }
    }
    document.getElementById("word").innerHTML=dashes.toString();
}
drawGallows();

function drawGallows() {
    if(strikes==1){
        document.getElementById("img").src = ("images/strike-1.png");
    }
    else if(strikes==2){
        document.getElementById("img").src = ("images/strike-2.png");
    } 
    else if(strikes==3){
        document.getElementById("img").src = ("images/strike-3.png");
    } 
    else if(strikes==4){
        document.getElementById("img").src = ("images/strike-4.png");
    } 
    else if(strikes==5){
        document.getElementById("img").src = ("images/strike-5.png");
    } 
    else if(strikes==6){
        document.getElementById("img").src = ("images/strike-6.png");
    } 
}
document.getElementById("form").addEventListener("submit",processGuess);

function processGuess(event) {
    event.preventDefault();
    let guess = document.getElementById("input").value.toUpperCase();
    console.log(guess);
    if (strikes < maxStrikes) {
        if(word.includes(guess)){
            for(let letterIndex=0; letterIndex<word.length; letterIndex++){
                if (word[letterIndex] == guess){
                        revealedLetters[letterIndex] = true;
                }
            }
            drawWordProgress();
        }
        else {
            strikes++;
            strikeLetters[strikes-1] = guess;
            drawStrikeLetters();
            drawGallows();
        }
        document.getElementById("guesses").value = "";
        let youWin = true;
        for (let correct of revealedLetters){
            if (!correct)
                youWin = false;
        }
        if (youWin){
            document.getElementById("img").src = ("images/player2wins.png");
            alert("Player 2 wins!")
        }
    }
    else{
        document.getElementById("img").src = ("images/player1wins.png");
        alert("Player 1 wins!");
    }
}